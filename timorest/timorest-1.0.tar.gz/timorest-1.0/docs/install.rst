.. _install:

Installation
============
Installing Timorest requires `Python <https://www.python.org/downloads>`_:

.. code-block:: console
	
    $ sudo python setup.py install
