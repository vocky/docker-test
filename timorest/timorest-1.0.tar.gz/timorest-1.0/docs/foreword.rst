.. _foreword:

foreword
========
+ This project depends on timo project.
+ You must ensure the shared library of TIMO_LIB_PATH is existed. You can refer to project Timo.
