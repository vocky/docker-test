.. _testing:

Testing
=======
Timorest use **nosetests** to do *tests*.

Change to the *tests* directory, and run tests with::

    $ nosetests
    .....
    ----------------------------------------------------------------------
    Ran 5 tests in 0.138s
    OK

    
